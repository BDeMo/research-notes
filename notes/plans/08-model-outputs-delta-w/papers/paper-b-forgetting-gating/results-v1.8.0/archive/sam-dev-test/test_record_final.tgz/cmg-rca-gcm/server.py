#!/usr/bin/env python3
"""cmg-rca-gcm: live interactive case-study server.
Mounts the trained GCM compressor (Qwen3-8B + mc_allthree adapter). For each real cmg case it compresses
raw telemetry -> 256-token memory M, identifies the root-cause module, and generates an RCA report from
THREE sources (no-context / truncated raw context / compressed M). Also a chatbot that answers questions
from the compressed memory. Pure stdlib HTTP server; inference serialized on one GPU.
"""
import os, json, re, string, threading, http.server, socketserver, urllib.parse
import torch
from transformers import TextIteratorStreamer
from gcm import GCMModel, enable_torch_linear_attention
enable_torch_linear_attention()
from gcm.lora import set_lora_enabled
from mem_embedding.gcm.runtime import Runtime
from mem_embedding.gcm.data import load_items, options_for

HERE = os.path.dirname(os.path.abspath(__file__))
def env(k, d): return os.environ.get(k, d)
MODEL = env("MODEL", "Qwen/Qwen3-8B"); ADAPTER = env("ADAPTER", "/mnt/persist/gcm/out/Qwen3-8B/mc_allthree_adapters.pt")
K = int(env("GCM_K", "256")); LORA = int(env("GCM_LORA", "64")); PORT = int(env("PORT", "8080"))
MAXCTX = int(env("GCM_MAXCTX", "8192"))           # full/truncated-read window (single forward)
ENC_MAXCTX = int(env("GCM_ENC_MAXCTX", "32768"))  # v1.8.0: compress sees up to this via recurrent chunking (no truncation)
FEATURED = [x for x in env("FEATURED", "").split(",") if x]
REPORT_Q = ("Based on the evidence above, produce a Root Cause Analysis report: Executive Summary (root-cause module, "
            "confidence, impact); Symptoms Observed; Root Cause Identification (module + mechanism); Fix Recommendation.\nRCA Report:\n")
os.environ.setdefault("GCM_REP_PENALTY", "1.15"); os.environ.setdefault("GCM_NO_REPEAT_NGRAM", "3")

print("[server] loading model ...", flush=True)
torch.set_grad_enabled(False); dev = "cuda:0"
rt = Runtime(MODEL, device=dev, n_memory=K, max_ctx_tokens=MAXCTX, max_new_tokens=400)
depth = int(rt.model.config.num_hidden_layers) // 2
model = GCMModel(rt.model, rt.tok, n_memory=K, depth=depth, proj_mult=2, lora_rank=LORA, normalize=True,
                 chunk_size=1024, recur=True).to(dev)
model.load_adapters(ADAPTER)
BENCH = env("BENCH", "cmg_all")  # cmg_all = ALL 38 cases; cmg_rca = 12-case val split
ITEMS = {it.item_id: it for it in load_items(BENCH, 60, 8, 1, "all")}
print(f"[server] loaded {MODEL} + {os.path.basename(ADAPTER)}; {len(ITEMS)} cmg cases", flush=True)
LOCK = threading.Lock(); CACHE = {}; GENC = {}

def _tok(s): return rt.tok(s, add_special_tokens=False, return_tensors="pt").input_ids.to(dev)

def full_cids(it):
    """v1.8.0 over-window feature: tokenize the FULL evidence up to ENC_MAXCTX and let the recurrent
    chunked compressor encode ALL of it (no MAXCTX truncation). The truncated single-forward baseline
    still uses rt.ctx_ids (capped at MAXCTX)."""
    ev = "".join(map(str, it.chunks or []))
    return rt.tok(ev, add_special_tokens=False, truncation=True, max_length=ENC_MAXCTX, return_tensors="pt").input_ids.to(dev)

def analyze(cid):
    """Module-ID + token/compression stats (fast). Cached."""
    if cid in CACHE: return CACHE[cid]
    it = ITEMS[cid]
    with LOCK:
        ev = "".join(map(str, it.chunks or []))
        ntok = len(rt.tok(ev, add_special_tokens=False).input_ids)
        opts = options_for(it); letters = list(string.ascii_uppercase)[:len(opts)]
        cids = rt.ctx_ids(it); qids = rt.query_ids(it)
        cidsF = full_cids(it)                       # v1.8.0: full untruncated context for the recurrent compressor
        M = model.encode(cidsF, qids)
        def pick(prefix, um):
            sc = model.mc_loglik(prefix, qids, letters, um)
            return opts[max(range(len(sc)), key=lambda k: sc[k])]
        gl = str(it.gold).strip(); gmod = opts[letters.index(gl)] if gl in letters else gl
        no = pick(None, False); fu = pick(model._embed(cids), False); cm = pick(M, True)
        ctx_seen = int(cids.shape[1])  # tokens the truncated baseline actually saw (<= MAXCTX)
        compress_seen = int(cidsF.shape[1])  # tokens the compressor actually encoded (<= ENC_MAXCTX)
    rec = {"id": cid, "gold_module": gmod, "options": opts,
           "evidence_tokens": ntok, "truncated_tokens": min(ntok, MAXCTX), "ctx_window_tokens": ctx_seen,
           "compress_seen_tokens": compress_seen, "over_window": ntok > MAXCTX,
           "K": K, "maxctx": MAXCTX, "compression_ratio": round(ntok / K, 1), "truncated": ntok > MAXCTX,
           "evidence": re.sub(r"\s+", " ", ev)[:1600],
           "no_ctx": no, "full_ctx": fu, "compress": cm,
           "compress_ok": cm == gmod, "full_ok": fu == gmod, "no_ok": no == gmod}
    CACHE[cid] = rec
    return rec

def gen_report(cid, mode):
    """Generate an RCA report for one source: mode in {no_ctx, trunc, compress}. Cached per (cid,mode)."""
    key = (cid, mode)
    if key in GENC: return GENC[key]
    it = ITEMS[cid]
    with LOCK:
        cids = rt.ctx_ids(it); q = _tok(REPORT_Q)
        if mode == "no_ctx":
            out = model._gen_batch([None], [q], False, 320, 1)[0]
        elif mode == "trunc":
            out = model._gen_batch([model._embed(cids)], [q], False, 320, 1)[0]
        else:  # compress (v1.8.0: encode the FULL untruncated context)
            M = model.encode(full_cids(it), _tok(REPORT_Q))
            out = model._gen_batch([M], [q], True, 340, 1)[0]
    GENC[key] = out.strip()
    return GENC[key]

def stream_gen(cid, mode, write):
    """Stream an RCA report token-by-token for one source (no_ctx/trunc/compress)."""
    import threading as _th
    it = ITEMS[cid]
    with LOCK:
        cids = rt.ctx_ids(it); q = _tok(REPORT_Q)
        if mode == "no_ctx": prefix, um = None, False
        elif mode == "trunc": prefix, um = model._embed(cids), False
        else: prefix, um = model.encode(full_cids(it), q), True   # v1.8.0: full untruncated compress
        set_lora_enabled(model.base, um)
        qe = model._embed(q)
        emb = torch.cat([prefix.to(qe.dtype), qe], 1) if prefix is not None else qe
        mask = torch.ones(1, emb.shape[1], dtype=torch.long, device=dev)
        pad = getattr(rt.tok, "pad_token_id", None) or getattr(rt.tok, "eos_token_id", 0)
        streamer = TextIteratorStreamer(rt.tok, skip_prompt=False, skip_special_tokens=True)
        kw = dict(inputs_embeds=emb, attention_mask=mask, max_new_tokens=320, do_sample=False, num_beams=1,
                  use_cache=True, repetition_penalty=1.15, no_repeat_ngram_size=3,
                  pad_token_id=int(pad), eos_token_id=getattr(rt.tok, "eos_token_id", None), streamer=streamer)
        th = _th.Thread(target=model.base.generate, kwargs=kw); th.start()
        acc = []
        for chunk in streamer:
            if chunk:
                acc.append(chunk); write(chunk)
        th.join()
    GENC[(cid, mode)] = "".join(acc).strip()


def chat(cid, question):
    """Answer a question from the COMPRESSED memory M (conditional compression on the question)."""
    it = ITEMS[cid]
    q = ("You are an RCA assistant. Using only the compressed evidence memory, answer the engineer's question "
         f"concisely and specifically.\nQuestion: {question.strip()}\nAnswer:\n")
    with LOCK:
        qids = _tok(q)
        M = model.encode(full_cids(it), qids)   # v1.8.0: chat over full untruncated compressed memory
        out = model._gen_batch([M], [qids], True, 240, 1)[0]
    return out.strip()

# Overall benchmark table (module-ID accuracy). Filled from eval runs; "null" => still computing.
# rows: internal cmg (cmg_rca) and public RCA (OpenRCA). cols: no-ctx / truncated-8k / vanilla-full / compressed-M.
OVERALL = {
  "model": "GCM · Qwen3-8B · K=256 · trained cmg_distill + cmg_aug + rca_openrca (distill=1.0)",
  "metric": "Module-ID accuracy = fraction of held-out cases where the predicted root-cause module "
            "(option with the highest multiple-choice log-likelihood) equals the gold module. Higher is better; modules are masked in the evidence.",
  "cols": [
    {"key": "no_ctx",   "label": "no context",        "hint": "Model sees only the question, no evidence at all. Lower-bound / prior baseline."},
    {"key": "trunc",    "label": "truncated full (8k)","hint": "Frozen base model reads the RAW evidence truncated to 8,192 tokens, then scores each module option. The 'vanilla full' that silently drops long evidence."},
    {"key": "full",     "label": "vanilla full",       "hint": "Frozen base reads the FULL raw evidence with NO truncation (window raised to ~12k tokens to fit), then scores options. Upper baseline at high token cost. N/A where evidence exceeds the window (OOM)."},
    {"key": "compress", "label": "compressed M",       "hint": "Trained GCM read-path scores options from the 256-token compressed memory M, which encodes the full evidence via recurrent compression (~25-48x fewer tokens)."},
  ],
  # Verified MC eval of mt_all_distill1 (Qwen3-8B, K=256). cmg n=12 is small + tie-prone (numbers swing); OpenRCA n=150 is reliable.
  "rows": [
    {"bench": "Internal CMG (cmg_rca, n=12)", "hint": "Nokia CMG fault cases, held-out validation (modules masked). Only 12 cases -> differences are within tie-break noise; treat as indicative, not significant.",
     "no_ctx": 0.17, "trunc": 0.33, "full": 0.25, "compress": 0.17},
    {"bench": "Public RCA (OpenRCA, n=150)", "hint": "Public OpenRCA benchmark, held-out validation (n=150, reliable). Evidence is long, so 'vanilla full' overflows the window (N/A); 'truncated full' reads up to 8k tokens.",
     "no_ctx": 0.16, "trunc": 0.80, "full": None, "compress": 0.18},
  ],
  "note": "Honest read: on the reliable public set (n=150), reading the raw evidence (truncated-full = 0.80) far outperforms the 256-token compressed M (0.18 ~= no-context 0.16) for module-ID. The compressor currently yields fluent, non-collapsed reports at a fraction of the tokens but does NOT recover the discriminative root-cause signal. cmg (n=12) is too small to separate the conditions.",
}

NPRECOMP = int(env("NPRECOMP", "40"))  # precompute all 38 by default
for cid in (FEATURED or list(ITEMS)):
    try: analyze(cid); print(f"[server] precomputed {cid}", flush=True)
    except Exception as e: print(f"[server] {cid} failed: {e}", flush=True)
    if not FEATURED and len(CACHE) >= NPRECOMP: break

class H(http.server.BaseHTTPRequestHandler):
    def _send(self, code, body, ctype="application/json"):
        b = body.encode() if isinstance(body, str) else body
        self.send_response(code); self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b))); self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers(); self.wfile.write(b)
    def log_message(self, *a): pass
    def do_GET(self):
        path, _, qs = self.path.partition("?"); q = urllib.parse.parse_qs(qs)
        try:
            if path in ("/", "/index.html"):
                self._send(200, open(os.path.join(HERE, "static", "index.html"), "rb").read(), "text/html")
            elif path == "/api/cases":
                feat = FEATURED or list(CACHE)
                order = feat + [c for c in ITEMS if c not in feat]
                rows = [{"id": c, **{k: (CACHE.get(c) or {}).get(k) for k in
                        ("gold_module", "compress", "compress_ok", "compression_ratio", "evidence_tokens", "truncated")},
                        "cached": c in CACHE} for c in order]
                self._send(200, json.dumps(rows))
            elif path == "/api/overall":
                # hot-updatable: read overall.json each request (fall back to embedded default)
                try: ov = json.load(open(os.path.join(HERE, "overall.json")))
                except Exception: ov = OVERALL
                # overlay LIVE cmg aggregate from the served model's precomputed cases so the
                # panel ALWAYS equals what the demo shows (auto-updates on every model hot-swap).
                cc = list(CACHE.values())
                if cc:
                    n = len(cc)
                    for r in ov.get("rows", []):
                        if str(r.get("bench", "")).lower().startswith("internal cmg"):
                            r["no_ctx"] = round(sum(bool(x.get("no_ok")) for x in cc) / n, 3)
                            r["trunc"] = round(sum(bool(x.get("full_ok")) for x in cc) / n, 3)
                            r["compress"] = round(sum(bool(x.get("compress_ok")) for x in cc) / n, 3)
                            r["bench"] = f"Internal CMG (cmg_rca, n={n}, live)"
                self._send(200, json.dumps(ov))
            elif path == "/api/reload":
                # hot-swap the served adapter in place (same arch K/LORA/depth) -> zero downtime
                newad = (q.get("adapter") or [""])[0]
                if not newad or not os.path.exists(newad):
                    self._send(404, json.dumps({"error": "adapter not found", "path": newad})); return
                def _do():
                    with LOCK:
                        model.load_adapters(newad); CACHE.clear(); GENC.clear()
                    for c in (FEATURED or list(ITEMS))[:NPRECOMP]:
                        try: analyze(c)
                        except Exception: pass
                    print(f"[server] hot-reloaded adapter -> {os.path.basename(newad)}", flush=True)
                threading.Thread(target=_do, daemon=True).start()
                self._send(200, json.dumps({"reloading": os.path.basename(newad)}))
            elif path == "/api/analyze":
                cid = (q.get("case") or [""])[0]
                self._send(200 if cid in ITEMS else 404, json.dumps(analyze(cid) if cid in ITEMS else {"error": "unknown"}))
            elif path == "/api/generate":
                cid = (q.get("case") or [""])[0]; mode = (q.get("mode") or ["compress"])[0]
                if cid not in ITEMS: self._send(404, json.dumps({"error": "unknown case"})); return
                self._send(200, json.dumps({"mode": mode, "text": gen_report(cid, mode)}))
            elif path == "/api/stream":
                cid = (q.get("case") or [""])[0]; mode = (q.get("mode") or ["compress"])[0]
                if cid not in ITEMS: self._send(404, json.dumps({"error": "unknown case"})); return
                self.send_response(200); self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Access-Control-Allow-Origin", "*"); self.send_header("Cache-Control", "no-cache"); self.end_headers()
                def w(s):
                    try: self.wfile.write(s.encode("utf-8")); self.wfile.flush()
                    except Exception: pass
                stream_gen(cid, mode, w)
            elif path == "/api/chat":
                cid = (q.get("case") or [""])[0]; ques = (q.get("q") or [""])[0]
                if cid not in ITEMS: self._send(404, json.dumps({"error": "unknown case"})); return
                self._send(200, json.dumps({"answer": chat(cid, ques)}))
            elif path.startswith("/static/"):
                fp = os.path.join(HERE, path.lstrip("/"))
                ct = "text/css" if fp.endswith(".css") else "application/javascript" if fp.endswith(".js") else "text/plain"
                self._send(200 if os.path.exists(fp) else 404, open(fp, "rb").read() if os.path.exists(fp) else "404", ct)
            else:
                self._send(404, "not found", "text/plain")
        except Exception as e:
            self._send(500, json.dumps({"error": str(e)}))

class TS(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True

print(f"[server] serving on 0.0.0.0:{PORT}", flush=True)
TS(("0.0.0.0", PORT), H).serve_forever()
